<?php
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "your_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle the request
$request = json_decode(file_get_contents('php://input'), true);

$response = [];

if ($request['message'] == "hostel availability") {
    $sql = "SELECT * FROM hostels WHERE available = 1";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $response['message'] = "We have the following hostels available:";
        while ($row = $result->fetch_assoc()) {
            $response['message'] .= "\n" . $row['name'];
        }
    } else {
        $response['message'] = "No hostels are currently available.";
    }
} else {
    $response['message'] = "I'm not sure how to respond to that. Can you please ask something else?";
}

$conn->close();
echo json_encode($response);
?>
