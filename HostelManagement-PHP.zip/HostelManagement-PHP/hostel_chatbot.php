<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents('php://input'), true);
$userMessage = strtolower($data['message']);

$response = '';

if (strpos($userMessage, 'book') !== false) {
    $response = 'To book a room, please visit our booking page at /booking or contact us directly at +123456789.';
} elseif (strpos($userMessage, 'price') !== false) {
    $response = 'Our prices start from $50 per night. For more details, visit our pricing page at /pricing.';
} elseif (strpos($userMessage, 'check availability') !== false) {
    $response = 'To check availability, please visit our availability page at /availability or contact us directly at +123456789.';
} else {
    $response = 'I am not sure how to help with that. Please visit our FAQ page at /faq for more information.';
}

echo json_encode(['reply' => $response]);
?>
