<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Hostel Management System </a>

<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book Hostel</title>
    <style>
    body {
        font-family: Arial, sans-serif;
        margin: 0;
        padding: 0;
    }

    #chatbot-widget {
        position: fixed;
        bottom: 20px;
        right: 20px;
        z-index: 1000;
    }

    #chatbot-toggle {
        width: 60px;
        height: 60px;
        background-color: #6A1B9A;
        color: white;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        cursor: pointer;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        transition: background-color 0.3s ease;
    }

    #chatbot-toggle:hover {
        background-color: #4A148C;
    }

    #chatbot-container {
        display: none;
        width: 320px;
        height: 440px;
        border: 1px solid #ccc;
        border-radius: 15px;
        overflow: hidden;
        background-color: white;
        box-shadow: 0 0 15px rgba(0, 0, 0, 0.2);
        margin-top: 10px;
        transition: transform 0.3s ease-in-out;
    }

    #chatbot {
        display: flex;
        flex-direction: column;
        height: 100%;
    }

    #chatbot-messages {
        flex: 1;
        padding: 15px;
        overflow-y: auto;
        border-bottom: 1px solid #ccc;
        background-color: #f9f9f9;
    }

    #chatbot-input-container {
        display: flex;
        padding: 10px;
        background-color: #fff;
        border-top: 1px solid #ccc;
    }

    #chatbot-input {
        flex: 1;
        padding: 10px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 14px;
        outline: none;
    }

    #chatbot-send {
        width: 60px;
        background-color: #6A1B9A;
        color: white;
        border: none;
        border-radius: 5px;
        margin-left: 10px;
        cursor: pointer;
        transition: background-color 0.3s ease;
        font-size: 16px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    #chatbot-send:hover {
        background-color: #4A148C;
    }

    .message {
        margin: 10px 0;
        padding: 10px;
        border-radius: 10px;
        max-width: 80%;
        line-height: 1.5;
        font-size: 14px;
        font-weight: bold;
    }

    .message.user {
        background-color: #9C27B0;
        color: white;
        align-self: flex-end;
    }

    .message.bot {
        background-color: #333;
        color: white;
        align-self: flex-start;
    }

    .loading {
        text-align: center;
        color: #333;
        font-style: italic;
    }

    .loading-spinner {
        display: inline-block;
        border: 4px solid #f3f3f3;
        border-top: 4px solid #6A1B9A;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        animation: spin 1s linear infinite;
        margin-left: 5px;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hostel Booking Chatbot</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        #chat-container {
            display: none;
            width: 400px;
            height: 500px;
            border: 1px solid #ccc;
            background-color: white;
            position: fixed;
            bottom: 20px;
            right: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex;
            flex-direction: column;
            justify-content: space-between;
        }
        .message {
            margin: 10px;
            padding-left: 10px;
        }
        .bot-message {
            color: #4B0082;
            background-color: #E6E6FA;
            border-radius: 5px;
            padding: 10px;
            margin-right: 20%;
        }
        .user-message {
            color: #FFFFFF;
            text-align: right;
            background-color: #6A5ACD;
            border-radius: 5px;
            padding: 10px;
            margin-left: 20%;
        }
        #message-box {
            flex-grow: 1;
            overflow-y: auto;
            padding: 10px;
        }
        .input-container {
            display: flex;
            padding: 10px;
            background-color: white;
            border-top: 1px solid #ccc;
        }
        input[type="text"] {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-right: 5px;
        }
        button {
            width: 20%;
            padding: 10px;
            background-color: #4B0082;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        #chat-icon {
            position: fixed;
            bottom: 20px;
            right: 20px;
            width: 60px;
            height: 60px;
            background-color: #6A5ACD;
            color: white;
            border-radius: 50%;
            display: flex;
            justify-content: center;
            align-items: center;
            cursor: pointer;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
        }
        #payment-window {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            width: 500px;
            height: 500px;
            background-color: rgba(255, 255, 255, 0.9);
            border: 1px solid #ccc;
            border-radius: 10px;
            padding: 20px;
            z-index: 1001;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
        }
        #payment-window h3 {
            margin-top: 0;
            color: #4B0082;
            text-align: center;
        }
        #bill-details {
            margin-top: 10px;
            line-height: 1.6;
            border-top: 1px dashed #aaa;
            padding-top: 10px;
        }
        #bill-details .bill-item {
            display: flex;
            justify-content: space-between;
            border-bottom: 1px dashed #aaa;
            padding: 8px 0;
        }
        #total-amount-section {
            font-weight: bold;
            text-align: right;
            border-top: 1px dashed #aaa;
            margin-top: 10px;
            padding-top: 10px;
        }
        #payment-window img {
            width: 100px;
            height: 100px;
            display: block;
            margin: 10px auto;
        }
        .confirm-message {
            text-align: center;
            color: green;
            font-weight: bold;
        }
    </style>
</head>
<body onclick="hideChat(event)">

<div id="chat-icon" onclick="toggleChat(event)">💬</div>

<div id="chat-container">
    <div id="message-box">
        <div class="message bot-message">Hello! Welcome to the Hostel Booking Assistant.</div>
        <div class="message bot-message">Let's get you started. May I know your name?</div>
    </div>
    <div class="input-container">
        <input type="text" id="user-input" placeholder="Type your message here..." onkeypress="handleKeyPress(event)">
        <button onclick="sendMessage()">Send</button>
    </div>
</div>

<div id="payment-window">
    <h3>Payment Invoice</h3>
    <div id="bill-details">
        <div class="bill-item"><span>Accommodation</span> <span id="accommodation-price">₹0</span></div>
        <div class="bill-item"><span>Meal Preference</span> <span id="meal-price">₹0</span></div>
        <div class="bill-item"><span>Laundry Service</span> <span id="laundry-price">₹0</span></div>
        <div id="total-amount-section">Total Amount: ₹<span id="total-amount">0</span></div>
    </div>
    <img src="https://api.qrserver.com/v1/create-qr-code/?data=Sample%20Data" alt="QR Code">
    <button onclick="confirmPayment()">Pay</button>
    <div class="confirm-message" id="confirm-message" style="display: none;">✔ Payment Successful!</div>
</div>

<script>
    let step = 0;
    let userData = {
        name: '', usn: '', semester: '', accommodationType: '',
        mealPreference: '', laundryService: '', paymentMode: '', duration: ''
    };

    const prices = {
        acsinglemonthly: 5000, acdoublemonthly: 3500, nonacsinglemonthly: 3000,
        nonacdoublemonthly: 2500, acsingleannual: 60000, acdoubleannual: 42000,
        nonacsingleannual: 36000, nonacdoubleannual: 30000, vegmeal: 1800,
        nonvegmeal: 2500, laundrymonthly: 200, laundryannual: 2200,
        securityFee: 500
    };

    const chatContainer = document.getElementById('chat-container');
    const userInput = document.getElementById('user-input');
    const messageBox = document.getElementById('message-box');
    const paymentWindow = document.getElementById('payment-window');
    const accommodationPrice = document.getElementById('accommodation-price');
    const mealPrice = document.getElementById('meal-price');
    const laundryPrice = document.getElementById('laundry-price');
    const totalAmount = document.getElementById('total-amount');
    const confirmMessage = document.getElementById('confirm-message');
    const chatIcon = document.getElementById('chat-icon');

    function toggleChat(event) {
        event.stopPropagation();
        chatContainer.style.display = 'flex';
        chatIcon.style.display = 'none';
        userInput.focus();
    }

    function hideChat(event) {
        if (!chatContainer.contains(event.target) && !paymentWindow.contains(event.target)) {
            chatContainer.style.display = 'none';
            paymentWindow.style.display = 'none';
            chatIcon.style.display = 'flex';
        }
    }

    function sendMessage() {
        const userText = userInput.value.trim();
        if (!userText) return;

        addMessage(userText, false);
        userInput.value = '';
        setTimeout(() => botResponse(userText), 500);
    }

    function botResponse(userText) {
    const keywords = {
        security: "Our hostel offers 24/7 security services to ensure your safety.",
        water: "We provide continuous water supply, including both drinking and bathing water.",
        amenities: "The hostel is equipped with amenities like a common room, gym, and study area.",
        electricity: "We ensure uninterrupted electricity supply with backup generators for your convenience."
    };

    // Check if the user input matches a keyword for additional info
    if (keywords[userText.toLowerCase()]) {
        addMessage(keywords[userText.toLowerCase()], true);
        return;
    }

    let botMessage = '';
    switch (step) {
        case 0:
            userData.name = userText;
            botMessage = 'Thank you, ' + userData.name + '. Next, I need your USN.';
            break;
        case 1:
            userData.usn = userText;
            botMessage = 'Got it. Which semester are you in?';
            break;
        case 2:
            userData.semester = userText;
            botMessage = 'Now, please select your accommodation preference: AC Single, AC Double, Non-AC Single, or Non-AC Double.';
            break;
        case 3:
            userData.accommodationType = userText.toLowerCase();
            botMessage = 'For duration, do you need it Monthly or Annual?';
            break;
        case 4:
            userData.duration = userText.toLowerCase();
            botMessage = 'Alright. How about meal preference – Veg or Non-Veg?';
            break;
        case 5:
            userData.mealPreference = userText.toLowerCase();
            botMessage = 'Would you like laundry service with your accommodation? Type Yes or No.';
            break;
        case 6:
            userData.laundryService = userText.toLowerCase();
            showPaymentWindow();
            return;
        default:
            botMessage = 'Processing your information...';
            break;
    }
    step++;
    addMessage(botMessage, true);
}


    function addMessage(text, isBot) {
        const message = document.createElement('div');
        message.className = isBot ? 'message bot-message' : 'message user-message';
        message.innerText = text;
        messageBox.appendChild(message);
        messageBox.scrollTop = messageBox.scrollHeight;
    }

    function showPaymentWindow() {
        chatContainer.style.display = 'none';
        paymentWindow.style.display = 'block';

        const accKey = userData.accommodationType + userData.duration;
        const mealKey = userData.mealPreference + 'meal';
        const laundryKey = userData.laundryService === 'yes' ? 'laundry' + userData.duration : null;

        accommodationPrice.innerText = '₹' + (prices[accKey] || 0);
        mealPrice.innerText = '₹' + (prices[mealKey] || 0);
        laundryPrice.innerText = '₹' + (laundryKey ? prices[laundryKey] : 0);

        const total = (prices[accKey] || 0) + (prices[mealKey] || 0) + (laundryKey ? prices[laundryKey] : 0) + prices.securityFee;
        totalAmount.innerText = total;
    }

    function confirmPayment() {
        confirmMessage.style.display = 'block';
        setTimeout(() => {
            confirmMessage.style.display = 'none';
            paymentWindow.style.display = 'none';
            chatContainer.style.display = 'flex';
            chatIcon.style.display = 'none';

            addMessage("Hi, any further queries?", true);
            addMessage("Don't forget, all accommodations come with 24/7 security, water facilities, electricity access, and a range of amenities to ensure your comfort!", true);
            
            step = 0;
            userData = {
                name: '', usn: '', semester: '', accommodationType: '', mealPreference: '', laundryService: '', paymentMode: '', duration: ''
            };
        }, 2000);
    }

    function handleKeyPress(event) {
        if (event.key === 'Enter') sendMessage();
    }
</script>
</body>
</html>










</footer>