<footer class="footer text-center text-muted">
&copy; <?php echo date("Y"); ?> - Hostel Management System - Developed by Team 27</a>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Hostel AI Chatbot</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-color: #f4f0fa;
    }

    .chatbot-toggle {
      position: fixed;
      bottom: 20px;
      right: 20px;
      width: 60px;
      height: 60px;
      background-color: #5e2c82;
      border-radius: 50%;
      color: white;
      font-size: 30px;
      display: flex;
      justify-content: center;
      align-items: center;
      cursor: pointer;
      box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
      z-index: 999;
      transition: transform 0.2s ease;
    }

    .chatbot-toggle:hover {
      transform: scale(1.1);
    }

    .chat-container {
      position: fixed;
      bottom: 90px;
      right: 20px;
      width: 360px;
      max-height: 600px;
      background-color: white;
      border-radius: 15px;
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
      display: none;
      flex-direction: column;
      overflow: hidden;
      z-index: 999;
      animation: fadeIn 0.3s ease-in-out;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .chat-header {
      background: linear-gradient(90deg, #5e2c82, #7b42f6);
      color: white;
      padding: 15px;
      font-weight: bold;
      text-align: center;
    }

    .chat-messages {
      flex: 1;
      padding: 10px;
      overflow-y: auto;
      background-color: #f3effa;
    }

    .message {
      margin: 8px 0;
      padding: 10px;
      border-radius: 8px;
      max-width: 85%;
      word-wrap: break-word;
      animation: slideIn 0.2s ease;
    }

    @keyframes slideIn {
      from { opacity: 0; transform: translateY(10px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .bot {
      background-color: #fff;
      border: 1px solid #ddd;
      color: #333;
    }

    .bot::before {
      content: '🤖 ';
    }

    .user {
      background-color: #d3bdfa;
      color: #fff;
      align-self: flex-end;
      text-align: right;
    }

    .chat-input {
      display: flex;
      border-top: 1px solid #ccc;
    }

    .chat-input input {
      flex: 1;
      border: none;
      padding: 15px;
      outline: none;
      font-size: 14px;
    }

    .chat-input button {
      background: linear-gradient(90deg, #5e2c82, #7b42f6);
      border: none;
      color: white;
      padding: 0 20px;
      cursor: pointer;
      font-weight: bold;
      transition: background 0.3s ease;
    }

    .chat-input button:hover {
      background: #4c2070;
    }

    .table {
      border-collapse: collapse;
      width: 100%;
      margin-top: 10px;
    }

    .table th,
    .table td {
      border: 1px solid #ccc;
      padding: 8px;
      text-align: center;
    }

    .table th {
      background-color: #e6d5fa;
    }

    .qr-container {
      text-align: center;
      padding: 15px;
      animation: fadeIn 0.3s ease-in-out;
    }

    .qr-container img {
      width: 180px;
      margin-bottom: 10px;
    }

    .qr-container button {
      background-color: #5e2c82;
      color: white;
      padding: 10px 20px;
      border: none;
      border-radius: 5px;
      font-size: 14px;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    .qr-container button:hover {
      background-color: #4c2070;
    }

    .tick {
      color: green;
      font-size: 18px;
    }
  </style>
</head>
<body>
  <div class="chatbot-toggle" onclick="toggleChat()">💬</div>

  <div class="chat-container" id="chatContainer">
    <div class="chat-header">AI Hostel Assistant</div>
    <div class="chat-messages" id="chatMessages"></div>
    <div class="chat-input">
      <input type="text" id="userInput" placeholder="Type a message..." onkeydown="if(event.key === 'Enter') sendMessage()" />
      <button onclick="sendMessage()">Send</button>
    </div>
  </div>

  <script>
    let selectedRoom = null;
    let selectedServices = [];

    const roomOptions = [
      { id: 1, type: 'Single Non-AC', price: 5000 },
      { id: 2, type: 'Single AC', price: 7000 },
      { id: 3, type: 'Sharing Non-AC', price: 3500 },
      { id: 4, type: 'Sharing AC', price: 5500 }
    ];

    const services = [
      { name: 'Meals', price: 1500 },
      { name: 'Laundry', price: 500 },
      { name: 'WiFi', price: 800 }
    ];

    const greetings = `Hi 👋 I'm here to help!<br>Type room or price to view options.`;
    document.addEventListener("DOMContentLoaded", () => addBotMessage(greetings));

    const hostelKeywords = [
  {
    keywords: ['pg', 'paying guest', 'hostel'],
    response: `🏠 Popular PGs & Hostels in Bengaluru:<br>
    • <strong>Comfort PG</strong> – MG Road (Near Trinity Metro Station), 📞 080-11111111<br>
    • <strong>CozyStay Hostel</strong> – Koramangala (Close to Forum Mall), 📞 080-22222222<br>
    • <strong>Student's Nest</strong> – BTM Layout (Near Udupi Garden Bus Stop), 📞 080-33333333`
  },
  {
    keywords: ['laundry', 'clothes wash'],
    response: `🧺 Laundry services available:<br>
    • Clothes are washed and ironed twice a week.<br>
    • Charges: ₹500/month<br>
    • Self-service washing machines also available in select hostels.`
  },
  {
    keywords: ['wifi', 'internet'],
    response: `📶 All hostels provide high-speed fiber internet.<br>
    • Typical speed: 100-200 Mbps<br>
    • Add-on charges: ₹800/month<br>
    • Available in rooms and common areas.`
  },
  {
    keywords: ['canteen', 'mess'],
    response: `🍛 Hostel canteens serve 3 meals a day:<br>
    • Vegetarian & Non-veg options<br>
    • Menu rotates weekly<br>
    • Meals cost ₹1500/month<br>
    • Example: South Indian meals, Chinese nights every Friday!`
  },
  {
    keywords: ['warden'],
    response: `👮 <strong>Hostel Warden</strong>:<br>
    • Name: Mr. Ramesh Kumar<br>
    • 📞 Contact: +91 9876543210<br>
    • Office Hours: 9 AM - 8 PM<br>
    • Located near the reception desk.`
  },
  {
    keywords: ['reception'],
    response: `📞 Reception Desk:<br>
    • Available 24x7 for support<br>
    • Phone: +91 9012345678<br>
    • Services: Visitor entry, ID cards, issues, courier collection.`
  },
  {
    keywords: ['security', 'guard'],
    response: `🔐 Security:<br>
    • 24x7 guards at entry/exit<br>
    • CCTV surveillance across premises<br>
    • Biometric entry for residents.`
  },
  {
    keywords: ['electricity', 'power cut'],
    response: `⚡ Electricity Info:<br>
    • 24x7 power with backup generator<br>
    • Inverter backup in all rooms<br>
    • Power cuts usually restored within 10 minutes.`
  },
  {
    keywords: ['water'],
    response: `🚿 Drinking & Utility Water:<br>
    • RO purified drinking water on each floor<br>
    • Hot water available 6 AM to 10 AM via solar geysers.`
  },
  {
    keywords: ['timing', 'curfew'],
    response: `🕒 Hostel Curfew:<br>
    • Girls: 9:30 PM | Boys: 10 PM<br>
    • Late entries allowed with parental consent.<br>
    • Security logs all entries/exits.`
  },
  {
    keywords: ['medical', 'doctor'],
    response: `🏥 Medical Assistance:<br>
    • Nearby Clinic: CityCare, Indiranagar (2 mins walk)<br>
    • On-call doctor available till 9 PM<br>
    • First-aid kits at reception and each floor.`
  },
  {
    keywords: ['gym'],
    response: `🏋️ In-house Gym Facilities:<br>
    • Open: 6 AM–10 AM & 6 PM–10 PM<br>
    • Equipment: Treadmills, weights, yoga mats<br>
    • Trainers available on weekends.`
  },
  {
    keywords: ['library'],
    response: `📚 Reading Rooms:<br>
    • Study spaces open 24x7 in Student’s Corner Hostel<br>
    • WiFi enabled, with charging docks<br>
    • Silent zones for focused study.`
  },
  {
    keywords: ['parking'],
    response: `🚗 Parking Facility:<br>
    • 2-wheeler: ₹300/month<br>
    • 4-wheeler (limited): ₹600/month<br>
    • Ask reception to register your vehicle.`
  },
  {
    keywords: ['guest', 'visitor'],
    response: `👥 Guest Policy:<br>
    • Visitors allowed from 10 AM to 6 PM<br>
    • Must show government-issued ID<br>
    • Overnight stays are not allowed.`
  },
  {
    keywords: ['rules', 'regulations'],
    response: `📋 Hostel Rules:<br>
    • No loud music after 10 PM<br>
    • Alcohol, smoking, and drugs strictly prohibited<br>
    • Follow university code of conduct<br>
    • Offenders reported to authorities.`
  },
  {
    keywords: ['cleaning', 'housekeeping'],
    response: `🧹 Cleaning Services:<br>
    • Rooms cleaned twice weekly<br>
    • Bathroom sanitation every alternate day<br>
    • You can request extra cleaning via reception.`
  },
  {
    keywords: ['indiranagar', 'koramangala', 'btm', 'hsr'],
    response: `📍 Hostels Available In:<br>
    • Indiranagar – Near 100ft Road (restaurants, cafés)<br>
    • Koramangala – Near Sony Signal (close to colleges)<br>
    • BTM Layout – Opp. Vega City Mall<br>
    • HSR Layout – Sector 1 & 2 (near startup hubs)`
  },
  {
    keywords: ['fees', 'charges'],
    response: `💰 Fee Structure:<br>
    • Room Rent: ₹3500 to ₹7000<br>
    • Service Charges (optional): Meals ₹1500, WiFi ₹800, Laundry ₹500<br>
    • Use ‘bill’ to calculate total for your selection.`
  },
  {
    keywords: ['support', 'help'],
    response: `📲 Helpdesk:<br>
    • Call us: +91 9876543211<br>
    • Available 24/7<br>
    • Or just type your question here — I'm always listening!`
  }
];


    function toggleChat() {
      const chat = document.getElementById("chatContainer");
      chat.style.display = chat.style.display === "none" || chat.style.display === "" ? "flex" : "none";
    }

    function sendMessage() {
      const input = document.getElementById("userInput");
      const text = input.value.trim();
      if (!text) return;
      addUserMessage(text);
      input.value = "";
      handleBotResponse(text.toLowerCase());
    }

    function addUserMessage(text) {
      const messages = document.getElementById("chatMessages");
      const msg = document.createElement("div");
      msg.className = "message user";
      msg.innerText = text;
      messages.appendChild(msg);
      messages.scrollTop = messages.scrollHeight;
    }

    function addBotMessage(text) {
      const messages = document.getElementById("chatMessages");
      const msg = document.createElement("div");
      msg.className = "message bot";
      msg.innerHTML = text;
      messages.appendChild(msg);
      messages.scrollTop = messages.scrollHeight;
    }

    function handleBotResponse(text) {
      if (["room", "price", "prices"].some(w => text.includes(w))) {
        let table = `<table class='table'><tr><th>Sl No</th><th>Type</th><th>Price (₹)</th></tr>`;
        roomOptions.forEach(r => {
          table += `<tr><td>${r.id}</td><td>${r.type}</td><td>${r.price}</td></tr>`;
        });
        table += `</table><p>Select your room using Sl No.</p>`;
        addBotMessage(table);
        return;
      }

      if (["1", "2", "3", "4"].includes(text)) {
        const id = parseInt(text);
        if (selectedRoom) {
          addBotMessage("❌ You already selected a room. Type 'cancel' to reset.");
        } else {
          selectedRoom = roomOptions.find(r => r.id === id);
          addBotMessage(`✅ Room selected: ${selectedRoom.type}. Now select services (meals, laundry, wifi).`);
          let serviceList = `<table class='table'><tr><th>Service</th><th>Price (₹)</th></tr>`;
          services.forEach(s => serviceList += `<tr><td>${s.name}</td><td>${s.price}</td></tr>`);
          serviceList += `</table>`;
          addBotMessage(serviceList);
        }
        return;
      }

      if (["meals", "laundry", "wifi"].includes(text)) {
        const service = services.find(s => s.name.toLowerCase() === text);
        if (!selectedServices.includes(service)) {
          selectedServices.push(service);
          addBotMessage(`✅ Service added: ${service.name}`);
        } else {
          addBotMessage(`❌ ${service.name} already selected.`);
        }
        return;
      }

      if (["cancel", "delete", "remove"].includes(text)) {
        selectedRoom = null;
        selectedServices = [];
        addBotMessage("❌ Selection cleared. You can start over.");
        return;
      }

      if (text.includes("bill")) {
        if (!selectedRoom) {
          addBotMessage("❌ Please select a room first.");
          return;
        }
        let total = selectedRoom.price;
        let summary = `<p>Room: ${selectedRoom.type} - ₹${selectedRoom.price}</p>`;
        selectedServices.forEach(s => {
          summary += `<p>${s.name}: ₹${s.price}</p>`;
          total += s.price;
        });
        summary += `<p><strong>Total: ₹${total}</strong></p>`;
        summary += `<button onclick="showPayment()">Pay Now</button>`;
        addBotMessage(summary);
        return;
      }

      // Keyword matching
      for (let entry of hostelKeywords) {
        for (let keyword of entry.keywords) {
          if (text.includes(keyword.toLowerCase())) {
            addBotMessage(entry.response);
            return;
          }
        }
      }

      addBotMessage("🤖 I didn't understand that.");
    }

    function showPayment() {
      let total = selectedRoom.price;
      selectedServices.forEach(s => total += s.price);
      
      const qr = `
        <div class='qr-container'>
          <img src='https://upload.wikimedia.org/wikipedia/commons/thumb/8/8f/Qr-2.png/600px-Qr-2.png' alt='QR Payment' />
          <p><strong>Total Amount: ₹${total}</strong></p>
          <p><button onclick='completePayment()'>Make Payment</button></p>
        </div>`;
      addBotMessage(qr);
    }

    function completePayment() {
      selectedRoom = null;
      selectedServices = [];
      addBotMessage("✅ Payment Completed. ");
      addBotMessage("Hi, how can I help?");
    }
  </script>
</body>
</html>
</footer>